package com.syntax.solution.rapidpay.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.Items;

import java.util.UUID;

public class AddItems extends AppCompatActivity {
    private EditText itemname,itemcategory,itemprice;
    private TextView itembarcode;
    private FirebaseAuth firebaseAuth;
    public static TextView resulttextview;
    Button scanbutton, additemtodatabase;
    FirebaseFirestore firebaseFirestore;
    public static final String PrefUid = "MyPrefsFile";
    String Cat_ID, Cat_Name;
    String User_ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        firebaseFirestore = FirebaseFirestore.getInstance();
        Cat_ID = getIntent().getStringExtra("Cat_Id");
        Cat_Name = getIntent().getStringExtra("Cat_Name");
        SharedPreferences prefs = getSharedPreferences(PrefUid, MODE_PRIVATE);
        User_ID = prefs.getString("UID", null);
        intial();

        scanbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ScanCode.class));
            }
        });


        additemtodatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                additem();
            }
        });



    }

    private void intial() {
        resulttextview = findViewById(R.id.barcodeview);
        additemtodatabase = findViewById(R.id.additembuttontodatabase);
        scanbutton = findViewById(R.id.buttonscan);
        itemname = findViewById(R.id.edititemname);
        itemcategory= findViewById(R.id.editcategory);
        itemprice = findViewById(R.id.editprice);
        itembarcode= findViewById(R.id.barcodeview);

    }


    public  void additem(){
        String itemnameValue = itemname.getText().toString();
        String itemcategoryValue = itemcategory.getText().toString();
        String itempriceValue = itemprice.getText().toString();
        String itembarcodeValue = itembarcode.getText().toString();
        if (itembarcodeValue.isEmpty()) {
            itembarcode.setError("It's Empty");
            itembarcode.requestFocus();
            return;
        }


        if(!TextUtils.isEmpty(itemnameValue)&&!TextUtils.isEmpty(itempriceValue)){
            String NODE = UUID.randomUUID().toString();
            Items items = new Items(itemnameValue,Cat_Name,itempriceValue,itembarcodeValue,Cat_ID,User_ID,NODE);
            firebaseFirestore.collection("Users").document(User_ID).collection("Categories").document(Cat_ID)
                    .collection("Items").document(NODE).set(items).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                itemname.getText().clear();
                                itembarcode.setText("");
                                itemprice.getText().clear();
                                itembarcode.setText("");
                                Toast.makeText(AddItems.this,itemnameValue+" Added",Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Toast.makeText(AddItems.this," Something went wrong",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }
        else {
            Toast.makeText(AddItems.this,"Please Fill all the fields",Toast.LENGTH_SHORT).show();
        }
    }


}