package com.syntax.solution.rapidpay.Activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.syntax.solution.rapidpay.Adapter.CategorieAdapter;
import com.syntax.solution.rapidpay.Adapter.DeleteCategoriesAdapter;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.CategoriesData;

import java.util.ArrayList;

public class DeleteCategories extends AppCompatActivity {
    RecyclerView recyclerView;
    FirebaseFirestore firebaseFirestore;
    ArrayList<CategoriesData> categories;
    DeleteCategoriesAdapter deleteCategoriesAdapter;
    String User_ID;
    public static final String PrefUid = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_categories);
        firebaseFirestore= FirebaseFirestore.getInstance();
        User_ID = getIntent().getStringExtra("User_Id");
        recyclerView = findViewById(R.id.recycler_view);
        categories = new ArrayList<>();
        SharedPreferences prefs = getSharedPreferences(PrefUid, MODE_PRIVATE);
        User_ID = prefs.getString("UID", null);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        deleteCategoriesAdapter = new DeleteCategoriesAdapter(this,categories);
        recyclerView.setAdapter(deleteCategoriesAdapter);
        firebaseFirestore.collection("Users").document(User_ID).collection("Categories").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                categories.clear();
                for (DocumentSnapshot snapshot:value.getDocuments()){
                    CategoriesData categoriesData =snapshot.toObject(CategoriesData.class);
                    categories.add(categoriesData);

                }
                deleteCategoriesAdapter.notifyDataSetChanged();
                deleteCategoriesAdapter.updateList(categories);

            }
        });



    }


}