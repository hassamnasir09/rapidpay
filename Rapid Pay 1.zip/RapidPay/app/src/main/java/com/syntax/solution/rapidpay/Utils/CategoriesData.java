package com.syntax.solution.rapidpay.Utils;

public class CategoriesData {
    String cat_id,cat_name,user_id;

    public CategoriesData(String cat_id, String cat_name, String user_id) {
        this.cat_id = cat_id;
        this.cat_name = cat_name;
        this.user_id = user_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public CategoriesData() {
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }
}
