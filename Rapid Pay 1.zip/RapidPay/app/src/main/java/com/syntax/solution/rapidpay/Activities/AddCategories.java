package com.syntax.solution.rapidpay.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.syntax.solution.rapidpay.Adapter.CategorieAdapter;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.CategoriesData;

import java.util.ArrayList;
import java.util.UUID;

public class AddCategories extends AppCompatActivity {
    RecyclerView recyclerView;
    FirebaseFirestore firebaseFirestore;
    Dialog dialog;
    EditText cat_Name;
    Button confirm;
    ImageButton imageButton;
    ArrayList<CategoriesData> categories;
    CategorieAdapter categorieAdapter;
    String User_ID;
    public static final String PrefUid = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_categories);
        intial();
        User_ID = getIntent().getStringExtra("User_Id");
        dialog = new Dialog(this,R.style.Theme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.add_cat_dialouge);
        cat_Name = dialog.findViewById(R.id.cat_Name);
        confirm = dialog.findViewById(R.id.confirm);
        categories = new ArrayList<>();
        firebaseFirestore = FirebaseFirestore.getInstance();
        imageButton.setOnClickListener(v -> {
            dialog.show();
        });
        SharedPreferences prefs = getSharedPreferences(PrefUid, MODE_PRIVATE);
        User_ID = prefs.getString("UID", null);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        categorieAdapter = new CategorieAdapter(this,categories);
        recyclerView.setAdapter(categorieAdapter);
        firebaseFirestore.collection("Users").document(User_ID).collection("Categories").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                categories.clear();
                for (DocumentSnapshot snapshot:value.getDocuments()){
                    CategoriesData categoriesData =snapshot.toObject(CategoriesData.class);
                    categories.add(categoriesData);

                }
                categorieAdapter.notifyDataSetChanged();
                categorieAdapter.updateList(categories);

            }
        });







        confirm.setOnClickListener(v -> {
            String NODE = UUID.randomUUID().toString();
            String v1 = cat_Name.getText().toString().trim();
            CategoriesData categories1 = new CategoriesData(NODE,v1,User_ID);
            firebaseFirestore.collection("Users").document(User_ID).collection("Categories").document(NODE).set(categories1)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                dialog.dismiss();
                                Toast.makeText(AddCategories.this, "New Category Add", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                dialog.dismiss();
                                Toast.makeText(AddCategories.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });


        });


    }

    private void intial() {

        recyclerView = findViewById(R.id.recycler_view);
        imageButton = findViewById(R.id.textBtn);
    }
}