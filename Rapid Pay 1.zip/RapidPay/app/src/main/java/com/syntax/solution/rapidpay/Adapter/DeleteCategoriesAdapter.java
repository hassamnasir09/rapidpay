package com.syntax.solution.rapidpay.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.syntax.solution.rapidpay.Activities.AddItems;
import com.syntax.solution.rapidpay.Activities.ViewProducts;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.CategoriesData;

import java.util.ArrayList;

public class DeleteCategoriesAdapter extends RecyclerView.Adapter<DeleteCategoriesAdapter.MyViewHolder> {
    Context context;
    ArrayList<CategoriesData> categories;

    public DeleteCategoriesAdapter(Context context, ArrayList<CategoriesData> categories) {
        this.context = context;
        this.categories = categories;
    }
    public void updateList(ArrayList<CategoriesData> list)
    {
        this.categories=list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DeleteCategoriesAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.delete_cat,parent,false);
        return new DeleteCategoriesAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DeleteCategoriesAdapter.MyViewHolder holder, int position) {

        CategoriesData categoriesData =categories.get(position);
        holder.textView.setText(categoriesData.getCat_name());
        String Cat_ID = categoriesData.getCat_id();
        String user_id = categoriesData.getUser_id();
        holder.textView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ViewProducts.class);
            intent.putExtra("Cat_Id",Cat_ID);
            context.startActivity(intent);

        });
        holder.delete.setOnClickListener(v -> {
            FirebaseFirestore.getInstance().collection("Users").document(user_id).collection("Categories")
                    .document(Cat_ID).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(context, "Category Deleted", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Toast.makeText(context, "Something went wrong", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        });

    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        Button delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView2);
            delete = itemView.findViewById(R.id.delete_cat);
        }
    }
}
