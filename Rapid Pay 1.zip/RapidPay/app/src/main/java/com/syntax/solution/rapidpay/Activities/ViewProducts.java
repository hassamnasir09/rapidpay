package com.syntax.solution.rapidpay.Activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.syntax.solution.rapidpay.Adapter.CategorieAdapter;
import com.syntax.solution.rapidpay.Adapter.ProductViewAdapter;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.Items;

import java.util.ArrayList;

public class ViewProducts extends AppCompatActivity {
    RecyclerView recyclerView;
    ProductViewAdapter productViewAdapter;
    FirebaseFirestore firebaseFirestore;
    ArrayList<Items> items;
    String Cat_ID;
    String User_ID;
    public static final String PrefUid = "MyPrefsFile";
    TextView textView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);
        firebaseFirestore = FirebaseFirestore.getInstance();
        recyclerView = findViewById(R.id.recycler_view);
        Cat_ID = getIntent().getStringExtra("Cat_Id");
        SharedPreferences prefs = getSharedPreferences(PrefUid, MODE_PRIVATE);
        User_ID = prefs.getString("UID", null);
        items = new ArrayList<>();
        textView= findViewById(R.id.text);

if (items!=null){
    recyclerView.setHasFixedSize(true);
    recyclerView.setLayoutManager(new LinearLayoutManager(this));
    productViewAdapter = new ProductViewAdapter(this,items);
    recyclerView.setAdapter(productViewAdapter);
    firebaseFirestore.collection("Users").document(User_ID).collection("Categories").document(Cat_ID)
            .collection("Items").addSnapshotListener(new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                    items.clear();
                    for (DocumentSnapshot documentSnapshot: value.getDocuments()){
                        Items items1 = documentSnapshot.toObject(Items.class);
                        items.add(items1);
                    }
                    productViewAdapter.notifyDataSetChanged();
                    productViewAdapter.updateList(items);

                }
            });


}
else {
    recyclerView.setVisibility(View.GONE);
    textView.setVisibility(View.VISIBLE);


}


    }
}