package com.syntax.solution.rapidpay.Utils;

public class UserInfoData {
    String  email, password, department;

    public UserInfoData(String email, String password, String department) {
        this.email = email;
        this.password = password;
        this.department = department;
    }

    public UserInfoData() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
