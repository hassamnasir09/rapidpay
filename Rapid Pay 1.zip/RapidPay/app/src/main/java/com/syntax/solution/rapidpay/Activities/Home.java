package com.syntax.solution.rapidpay.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.syntax.solution.rapidpay.R;

public class Home extends AppCompatActivity {
    String User_ID;
    private FirebaseAuth firebaseAuth;
    CardView addItems,deleteItems,logout,scanItems;
    public static final String PrefUid = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        User_ID = getIntent().getStringExtra("User_Id");

        firebaseAuth = FirebaseAuth.getInstance();

        final FirebaseUser users = firebaseAuth.getCurrentUser();


        addItems = findViewById(R.id.addItems);
        addItems.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, AddCategories.class);
            intent.putExtra("User_Id",User_ID);
            startActivity(intent);
        });

        deleteItems= findViewById(R.id.deleteItems);
        deleteItems.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, DeleteCategories.class);
            intent.putExtra("User_Id",User_ID);
            startActivity(intent);
        });

        scanItems= findViewById(R.id.scanItems);
        scanItems.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, DeleteCategories.class);
            intent.putExtra("User_Id",User_ID);
            startActivity(intent);
        });


        logout = findViewById(R.id.logout);
        logout.setOnClickListener(v -> {
            firebaseAuth.signOut();
            SharedPreferences.Editor editor = getSharedPreferences(PrefUid, MODE_PRIVATE).edit();
            editor.clear();
            editor.apply();
            Intent i = new Intent(Home.this, MainActivity.class);
            String data="logout";
            i.putExtra("key",data);
            startActivity(i);
            finish();

        });

    }
}