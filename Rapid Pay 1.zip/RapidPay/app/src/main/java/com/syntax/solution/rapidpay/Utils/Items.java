package com.syntax.solution.rapidpay.Utils;

public class Items {


        private String itemname;
        private String itemcategory;
        private String itemprice;
        private String itembarcode;
        private String Cat_Id;
        private String User_Id;
        private String Product_Id;


        public Items() {

        }

    public Items(String itemname, String itemcategory, String itemprice, String itembarcode, String cat_Id, String user_Id, String product_Id) {
        this.itemname = itemname;
        this.itemcategory = itemcategory;
        this.itemprice = itemprice;
        this.itembarcode = itembarcode;
        Cat_Id = cat_Id;
        User_Id = user_Id;
        Product_Id = product_Id;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getItemcategory() {
        return itemcategory;
    }

    public void setItemcategory(String itemcategory) {
        this.itemcategory = itemcategory;
    }

    public String getItemprice() {
        return itemprice;
    }

    public void setItemprice(String itemprice) {
        this.itemprice = itemprice;
    }

    public String getItembarcode() {
        return itembarcode;
    }

    public void setItembarcode(String itembarcode) {
        this.itembarcode = itembarcode;
    }

    public String getCat_Id() {
        return Cat_Id;
    }

    public void setCat_Id(String cat_Id) {
        Cat_Id = cat_Id;
    }

    public String getUser_Id() {
        return User_Id;
    }

    public void setUser_Id(String user_Id) {
        User_Id = user_Id;
    }

    public String getProduct_Id() {
        return Product_Id;
    }

    public void setProduct_Id(String product_Id) {
        Product_Id = product_Id;
    }
}
