package com.syntax.solution.rapidpay.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.syntax.solution.rapidpay.Activities.AddItems;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.CategoriesData;

import java.util.ArrayList;

public class CategorieAdapter extends RecyclerView.Adapter<CategorieAdapter.MyViewHolder> {
    Context context;
    ArrayList<CategoriesData> categories;

    public CategorieAdapter(Context context, ArrayList<CategoriesData> categories) {
        this.context = context;
        this.categories = categories;
    }
    public void updateList(ArrayList<CategoriesData> list)
    {
        this.categories=list;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public CategorieAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cat_items,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategorieAdapter.MyViewHolder holder, int position) {
        CategoriesData categoriesData =categories.get(position);
        holder.textView.setText(categoriesData.getCat_name());
        String Cat_ID = categoriesData.getCat_id();
        String Cat_Name = categoriesData.getCat_name();
        holder.textView.setOnClickListener(v -> {
            Intent intent = new Intent(context, AddItems.class);
            intent.putExtra("Cat_Id",Cat_ID);
            intent.putExtra("Cat_Name",Cat_Name);

            context.startActivity(intent);



        });

    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView2);

        }
    }
}
