package com.syntax.solution.rapidpay.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.syntax.solution.rapidpay.R;
import com.syntax.solution.rapidpay.Utils.CategoriesData;
import com.syntax.solution.rapidpay.Utils.Items;

import java.util.ArrayList;

public class ProductViewAdapter extends RecyclerView.Adapter<ProductViewAdapter.MyViewHolder> {
    Context context;
    ArrayList<Items> items;

    public ProductViewAdapter(Context context, ArrayList<Items> items) {
        this.context = context;
        this.items = items;
    }
    public void updateList(ArrayList<Items> list)
    {
        this.items=list;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ProductViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.products_items,parent,false);
        return new ProductViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewAdapter.MyViewHolder holder, int position) {
        Items items1 = items.get(position);
        holder.viewitembarcode.setText(items1.getItembarcode());
        holder.viewitemname.setText(items1.getItemname());
        holder.viewitemprice.setText(items1.getItemprice());
        holder.viewitemcategory.setText(items1.getItemcategory());
        String User_ID = items1.getUser_Id();
        String Cat_ID = items1.getCat_Id();
        String Item_ID = items1.getProduct_Id();


        holder.product_delete.setOnClickListener(v -> {
            FirebaseFirestore.getInstance().collection("Users").document(User_ID).collection("Categories").document(Cat_ID)
                    .collection("Items").document(Item_ID).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(context, "Product Deleted", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Toast.makeText(context, "Something went wrong", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        });



    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView viewitembarcodename,viewitemnamename,viewitempricename,viewitemcategoryname;
        TextView viewitembarcode,viewitemname,viewitemprice,viewitemcategory;
        Button product_delete;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            viewitembarcode = itemView.findViewById(R.id.viewitembarcode);
            viewitemname= itemView.findViewById(R.id.viewitemname);
            viewitemprice= itemView.findViewById(R.id.viewitemprice);
            viewitemcategory= itemView.findViewById(R.id.viewitemcategory);
            product_delete= itemView.findViewById(R.id.product_delete);

        }
    }
}
